# GoalSense AI starter

Mobile-first React/Vite frontend + FastAPI backend. Demo fixtures and rates are fictional examples, not real matches or validated forecasts.

## Run backend
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload

## Run frontend in another terminal
cd frontend
npm install
npm run dev

Open the Vite URL (normally http://localhost:5173). Backend docs: http://localhost:8000/docs.

Live data is not connected yet. Add a provider adapter in backend/app/providers.py and keep API keys in server-side environment variables. Before using real predictions, train and test against chronological historical data and evaluate calibration/out-of-sample accuracy.
