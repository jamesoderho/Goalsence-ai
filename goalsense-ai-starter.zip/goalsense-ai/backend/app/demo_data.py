from .models import Match

# Fictional demo fixtures and inputs. Not real-world football data.
MATCHES = [
    Match(id=1, league="Demo Premier Division", country="Demo", kickoff="2026-11-08T15:00:00Z",
          home="Harbour FC", away="Valley United", home_scored=1.65, home_conceded=0.95,
          away_scored=1.20, away_conceded=1.45),
    Match(id=2, league="Demo National League", country="Demo", kickoff="2026-11-08T17:30:00Z",
          home="Metro Athletic", away="Riverside Town", home_scored=1.35, home_conceded=1.10,
          away_scored=1.55, away_conceded=1.30),
    Match(id=3, league="Demo Coastal League", country="Demo", kickoff="2026-11-09T14:00:00Z",
          home="Forest Rovers", away="Eastern Stars", home_scored=1.80, home_conceded=1.20,
          away_scored=0.90, away_conceded=1.60),
]
