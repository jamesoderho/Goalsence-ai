from pydantic import BaseModel

class Match(BaseModel):
    id: int
    league: str
    country: str
    kickoff: str
    home: str
    away: str
    home_scored: float
    home_conceded: float
    away_scored: float
    away_conceded: float
    note: str = "Illustrative demo fixture"

class Prediction(BaseModel):
    home_win: float
    draw: float
    away_win: float
    btts_yes: float
    over_25: float
    predicted_score: str
    disclaimer: str
