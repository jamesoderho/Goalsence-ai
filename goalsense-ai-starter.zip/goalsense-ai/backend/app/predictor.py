import math
from .models import Match, Prediction

def poisson(k: int, lam: float) -> float:
    return math.exp(-lam) * (lam ** k) / math.factorial(k)

def predict(match: Match) -> Prediction:
    # Illustrative baseline blending scoring and opponent-concession rates.
    home_xg = max(0.15, (match.home_scored + match.away_conceded) / 2 * 1.08)
    away_xg = max(0.15, (match.away_scored + match.home_conceded) / 2)
    probs_h = [poisson(i, home_xg) for i in range(9)]
    probs_a = [poisson(i, away_xg) for i in range(9)]
    hw = dr = aw = btts = over25 = 0.0
    best = (0, 0, -1.0)
    for h, ph in enumerate(probs_h):
        for a, pa in enumerate(probs_a):
            p = ph * pa
            if h > a: hw += p
            elif h == a: dr += p
            else: aw += p
            if h > 0 and a > 0: btts += p
            if h + a > 2: over25 += p
            if p > best[2]: best = (h, a, p)
    total = hw + dr + aw
    return Prediction(
        home_win=round(hw / total * 100, 1),
        draw=round(dr / total * 100, 1),
        away_win=round(aw / total * 100, 1),
        btts_yes=round(btts * 100, 1),
        over_25=round(over25 * 100, 1),
        predicted_score=f"{best[0]}–{best[1]}",
        disclaimer="DEMO estimate from fictional inputs. Not a real fixture forecast or betting guarantee."
    )
