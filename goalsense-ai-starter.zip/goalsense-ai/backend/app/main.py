from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .models import Match, Prediction
from .demo_data import MATCHES
from .predictor import predict

app = FastAPI(title="GoalSense AI API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health():
    return {"status": "ok", "mode": "DEMO"}

@app.get("/matches", response_model=list[Match])
def matches():
    return MATCHES

@app.get("/matches/{match_id}/prediction", response_model=Prediction)
def match_prediction(match_id: int):
    match = next((m for m in MATCHES if m.id == match_id), None)
    if match is None:
        raise HTTPException(status_code=404, detail="Match not found")
    return predict(match)
