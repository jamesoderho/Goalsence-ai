import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const API = 'http://localhost:8000';

function App() {
  const [matches, setMatches] = useState([]);
  const [selected, setSelected] = useState(null);
  const [prediction, setPrediction] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch(`${API}/matches`).then(r => {
      if (!r.ok) throw new Error('Backend unavailable');
      return r.json();
    }).then(setMatches).catch(() => setError('Cannot reach the API. Start the backend and refresh.'));
  }, []);

  async function showPrediction(match) {
    setSelected(match); setPrediction(null); setError('');
    try {
      const r = await fetch(`${API}/matches/${match.id}/prediction`);
      if (!r.ok) throw new Error();
      setPrediction(await r.json());
    } catch { setError('Prediction unavailable. Check the backend.'); }
  }

  return <main className="shell">
    <header className="topbar">
      <div className="brand-mark">GS</div>
      <div><div className="brand">GOALSENSE <span>AI</span></div><div className="tagline">FOOTBALL INTELLIGENCE</div></div>
      <div className="demo-pill">DEMO MODE</div>
    </header>
    <section className="hero">
      <p className="eyebrow">MATCH CENTRE</p>
      <h1>See the game<br/><em>through data.</em></h1>
      <p className="sub">Explore match statistics and probability estimates across competitions.</p>
      <div className="hero-stats">
        <div><b>1X2</b><small>OUTCOMES</small></div>
        <div><b>O/U 2.5</b><small>GOALS</small></div>
        <div><b>BTTS</b><small>SCORING</small></div>
      </div>
    </section>
    <section className="section-head"><div><p className="eyebrow">UPCOMING</p><h2>Demo fixtures</h2></div><span className="count">{matches.length} MATCHES</span></section>
    {error && <div className="notice">{error}</div>}
    <div className="match-list">{matches.map(m => <button className={`match-card ${selected?.id === m.id ? 'active' : ''}`} key={m.id} onClick={() => showPrediction(m)}>
      <div className="match-meta"><span>{m.country} · {m.league}</span><span>{new Date(m.kickoff).toLocaleString()}</span></div>
      <div className="teams"><strong>{m.home}</strong><span className="vs">VS</span><strong>{m.away}</strong></div>
      <div className="match-foot"><span>View AI analysis</span><span className="arrow">↗</span></div>
    </button>)}</div>
    {selected && <section className="analysis">
      <p className="eyebrow">MATCH ANALYSIS</p><h2>{selected.home} <span className="muted">vs</span> {selected.away}</h2>
      {!prediction ? <p className="sub">Calculating estimate…</p> : <>
        <div className="score-box"><small>MOST LIKELY SCORE</small><div>{prediction.predicted_score}</div></div>
        <h3>1X2 probabilities</h3>
        <div className="prob-grid">
          <Probability label="HOME" value={prediction.home_win}/>
          <Probability label="DRAW" value={prediction.draw}/>
          <Probability label="AWAY" value={prediction.away_win}/>
        </div>
        <div className="market-row">
          <div><small>BOTH TEAMS TO SCORE</small><b>{prediction.btts_yes}%</b></div>
          <div><small>OVER 2.5 GOALS</small><b>{prediction.over_25}%</b></div>
        </div>
        <p className="disclaimer">{prediction.disclaimer}</p>
      </>}
    </section>}
    <footer>GOALSENSE AI <span>·</span> EARLY ACCESS PROTOTYPE</footer>
  </main>;
}
function Probability({label, value}) {
  return <div className="prob"><small>{label}</small><b>{value}%</b><div className="track"><i style={{width:`${value}%`}}/></div></div>;
}
createRoot(document.getElementById('root')).render(<App/>);
